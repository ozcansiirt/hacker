# akira2.0
A Dedicated script for DDOS, DRDOS &amp; The so called DOS. It includes more than 3K+ Botnet connections so just chill &amp; fuck the corrupt government..!
