#!/bin/sh
apt install python3 --yes
apt install python3-pip --yes
pip3 install --upgrade pip
pip3 install requests netaddr
pip3 install --upgrade requests
